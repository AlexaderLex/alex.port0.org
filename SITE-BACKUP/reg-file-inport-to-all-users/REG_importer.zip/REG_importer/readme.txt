REG Importer
imports specified reg file(s) to all users including default user.

usage example Reg_importer regfile1.reg regfile2.reg regfile3.reg
running without parameters shows "open file" dialog

; https://it-howto.info/reg-file-inport-to-all-users
; IT HowTO © 2018
