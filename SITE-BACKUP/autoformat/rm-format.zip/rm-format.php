<?php

/* 
* Plugin Name: Отключение автоформата
* Author: Alex Brikovsky
* Author URI: https://it-howto.info/
* Plugin URI: https://it-howto.info/wp-no-autoformat
* Version: 1.0
* Description: Очень простой плагин для отключения автоматического форматирования Wordpress. Отключает преобразование кавычек, добавление тега &lt;p&gt; и форматирование слова Wordpress
*/


# отключение расстановки тегов параграфов
remove_filter('the_content', 'wpautop');     //записи
remove_filter('the_excerpt', 'wpautop');     //цитаты



# Убираем «улучшение» текста
remove_filter('category_description', 'wptexturize');
remove_filter('list_cats', 'wptexturize');
remove_filter('comment_author', 'wptexturize');
remove_filter('comment_text', 'wptexturize');
remove_filter('single_post_title', 'wptexturize');
remove_filter('the_title', 'wptexturize');
remove_filter('the_content', 'wptexturize');
remove_filter('the_excerpt', 'wptexturize');


# отключение форматирования слова WordPress
remove_filter('the_content', 'capital_P_dangit',11);    //записи
remove_filter('the_excerpt', 'capital_P_dangit',11);    //цитаты
remove_filter('comment_text', 'capital_P_dangit',31);   //комментарии



add_filter('tiny_mce_before_init', 'vsl2014_filter_tiny_mce_before_init');
function vsl2014_filter_tiny_mce_before_init( $options ) {

    if ( ! isset( $options['extended_valid_elements'] ) ) {
        $options['extended_valid_elements'] = 'style';
    } else {
        $options['extended_valid_elements'] .= ',style';
    }

    if ( ! isset( $options['valid_children'] ) ) {
        $options['valid_children'] = '+body[style]';
    } else {
        $options['valid_children'] .= ',+body[style]';
    }

    if ( ! isset( $options['custom_elements'] ) ) {
        $options['custom_elements'] = 'style';
    } else {
        $options['custom_elements'] .= ',style';
    }

    return $options;
}
